package com.example.cloudpssproj.cpcontroller;

import com.cloudpss.model.Model;
import com.cloudpss.model.implementations.DiagramCell;
import com.cloudpss.runner.Runner;
import com.example.cloudpssproj.cpservice.ReadPssService;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import io.swagger.annotations.ApiOperation;
import net.rubyeye.xmemcached.exception.MemcachedException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;
import java.util.concurrent.TimeoutException;

@RequestMapping(value = "/demo")
@RestController
public class PssController {

    @Autowired
    ReadPssService readPssService;

    @GetMapping("/test/pssTst")
    @ApiOperation("测试set")
    public String pssTst(String[] args) throws Exception {
        String token = "eyJhbGciOiJFUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NjI2LCJ1c2VybmFtZSI6Imd1YW4yNSIsInNjb3BlcyI6W10sInR5cGUiOiJhcHBseSIsImV4cCI6MTY5OTQ1ODYxMiwiaWF0IjoxNjk0Mjc0NjEyfQ.7cn8HBBUiZGILfCAKFO_g9LgSM0hRxZt2IW40szu4FAlJte_fUndkscVb8zGdrYTBTm5j5OV8YPUyYtuyBMIng";
        System.setProperty("CLOUDPSS_TOKEN", token);
        String rid = "model/CloudPSS/IEEE3";
        Model model = Model.fetch(rid);
        Map<String, DiagramCell> allCells = model.getAllComponents();
        Map<String, DiagramCell> cells = model.getComponentsByRid("model/CloudPSS/_newBus_3p");
        System.out.println(cells);
        DiagramCell cell = model.getComponentByKey("canvas_0_1065");
        Map<String, Object> cellArgs = cell.getArgs();
        cellArgs.put("Length", "1.01");
        Runner runner = model.run();
        String taskid = runner.getTaskId();
        System.out.println("end");
        return "succes";
    }

    @GetMapping("/test/cloudpssTst")
    @ApiOperation("测试set")
    public String cloudpssTst(String[] args) throws Exception {
        // 每个人需要注册自己的token
        //String token = "eyJhbGciOiJFUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NjI2LCJ1c2VybmFtZSI6Imd1YW4yNSIsInNjb3BlcyI6W10sInR5cGUiOiJhcHBseSIsImV4cCI6MTY5OTQ1ODYxMiwiaWF0IjoxNjk0Mjc0NjEyfQ.7cn8HBBUiZGILfCAKFO_g9LgSM0hRxZt2IW40szu4FAlJte_fUndkscVb8zGdrYTBTm5j5OV8YPUyYtuyBMIng";

        //System.setProperty("CLOUDPSS_API_URL", "http://166.111.60.221:60002/");
        //System.setProperty("CLOUDPSS_TOKEN", token);
        String rid = "model/dpshsw/IEEE39";

        // 加载一个项目
        Model model = Model.fetch(rid);

        // 数据存储通过 result 获取，需要自己监控运行状态，result 为一个迭代器
        Runner runner = model.run();// 启动计算
        String taskid = runner.getTaskId();
        int n = 0;
        boolean flag = false;

        while (runner.status() == 0) {
            System.out.println("Simulation is running. Waiting ...... " + n);
            Thread.sleep(2000);
            n++;

            if (n > 40 && !flag)
                break;

            if (!runner.result.hasNext())
                continue;

            JsonParser jParser = new JsonParser();
            int lastId = runner.result.getMessage().size() - 1;
            if (lastId < 10)
                continue;
            // 提取第i个点的数据
            String msg = runner.result.getMessage().get(lastId);
            // System.out.println("msg="+msg);
            JsonObject jts = (JsonObject) jParser.parse(msg);
            if (!jts.get("cmd").getAsString().equals("draw"))
                continue;
            // 提取第i个点的数据中的data;
            JsonObject jt = (JsonObject) jParser.parse(jts.get("data").toString());
            if (jt == null)
                continue;
            System.out.println("jt=" + jt);
            String key = "/canvas_11_1023:0";
            if (jt.get(key) == null) {
                System.out.println("key error: " + key);
                continue;
            }
            flag = true;
            JsonArray a = jt.get(key).getAsJsonArray();
            int l = a.size();
            JsonArray b = a.get(l - 1).getAsJsonArray();
            System.out.print("\t t = " + b.get(0).getAsDouble());
            System.out.println("\t val= " + b.get(1).getAsDouble());

            // 提前指定通道的值
            // canvas_11_1088~canvas_11_1097 代表10个发电机的机端电流
            // canvas_11_1023~canvas_11_1032 代表10个发电机的机端电压
            // 0,1,2代表A，B，C三相
            // System.out.println(jt.get("/canvas_11_1023:0"));//打印发电机31的A相电压
            // 以下代码为读取K33f的值
            // Todo: 读取多个通道的值

            key = "/component_new_channel_439:0"; // K33f
            if (jt.get(key) == null) {
                System.out.println("key error: " + key);
                continue;
            }
            a = jt.get(key).getAsJsonArray();
            l = a.size();
            b = a.get(l - 1).getAsJsonArray();
            System.out.print("\tt = " + b.get(0).getAsDouble());
            System.out.println("\tval= " + b.get(1).getAsDouble());
        }

        return "succes";
    }

    @GetMapping("/test/cloudpssGet")
    @ApiOperation("测试pss")
    String cloudPssGet() throws Exception {
        readPssService.readPss();
        return "ok";
    }

    @GetMapping("/test/getMem")
    @ApiOperation("测试getPssMem")
    public Object testMemGetPss() throws InterruptedException, TimeoutException, MemcachedException {
        return readPssService.getPssMsgMem();
    }

}
