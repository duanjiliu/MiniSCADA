package com.example.cloudpssproj.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.cloudpssproj.entity.Connectivitynode;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author xiaolu
 * @since 2023-09-12
 */
public interface IConnectivitynodeService extends IService<Connectivitynode> {

}
