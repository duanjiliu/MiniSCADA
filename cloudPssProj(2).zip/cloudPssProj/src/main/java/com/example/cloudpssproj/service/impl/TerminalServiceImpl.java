package com.example.cloudpssproj.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.cloudpssproj.entity.Terminal;
import com.example.cloudpssproj.mapper.TerminalMapper;
import com.example.cloudpssproj.service.ITerminalService;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author xiaolu
 * @since 2023-09-12
 */
@Service
public class TerminalServiceImpl extends ServiceImpl<TerminalMapper, Terminal> implements ITerminalService {

}
