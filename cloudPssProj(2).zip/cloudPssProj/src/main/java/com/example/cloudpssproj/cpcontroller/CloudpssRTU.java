package com.example.cloudpssproj.cpcontroller;

import com.cloudpss.model.Model;
import com.cloudpss.runner.Runner;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class CloudpssRTU {

    public static void main1(String[] args) throws Exception {

        // 每个人需要注册自己的token
        String token = "XXX Your Token YYY";

        System.setProperty("CLOUDPSS_API_URL", "http://166.111.60.221:60002/");
        System.setProperty("CLOUDPSS_TOKEN", token);
        String rid = "model/dpshsw/IEEE39";

        // 加载一个项目
        Model model = Model.fetch(rid);

        /*
         * // 获取指定 key 的元件
         * DiagramCell cell =
         * model.getComponentByKey("component_new_constant_89");//对应T33f
         * 
         * // 获取元件的参数消息，并修改元件参数
         * Map<String, Object> cellArgs = cell.getArgs();
         * for(String key : cellArgs.keySet())
         * {
         * System.out.println("key ="+key+"  Value="+cellArgs.get(key));
         * }
         * 
         * // 获取所有的元件
         * Map<String, DiagramCell> allCells = model.getAllComponents();
         * 
         * // 获取通过 rid 获取元件
         * Map<String, DiagramCell> cells = model.getComponentsByRid(rid);
         * System.out.println(cells);
         * 
         * // 获取指定 key 的元件
         * DiagramCell cell = model.getComponentByKey("canvas_1_16");//对应发电机37，
         * 
         * // 获取元件的参数消息，并修改元件参数
         * Map<String, Object> cellArgs = cell.getArgs();
         * cellArgs.put("Smva", "1500");//举例，修改其（发电机37）容量为1500MVA，
         */

        // 数据存储通过 result 获取，需要自己监控运行状态，result 为一个迭代器
        Runner runner = model.run();// 启动计算
        String taskid = runner.getTaskId();
        int n = 0;
        boolean flag = false;
        while (runner.status() == 0) {
            System.out.println("Simulation is running. Waiting ...... " + n);
            Thread.sleep(2000);
            n++;

            if (n > 40 && !flag)
                break;

            if (!runner.result.hasNext())
                continue;

            JsonParser jParser = new JsonParser();
            int lastId = runner.result.getMessage().size() - 1;
            if (lastId < 10)
                continue;
            // 提取第i个点的数据
            String msg = runner.result.getMessage().get(lastId);
            // System.out.println("msg="+msg);
            JsonObject jts = (JsonObject) jParser.parse(msg);
            if (!jts.get("cmd").getAsString().equals("draw"))
                continue;
            // 提取第i个点的数据中的data;
            JsonObject jt = (JsonObject) jParser.parse(jts.get("data").toString());
            if (jt == null)
                continue;
            System.out.println("jt=" + jt);
            String key = "/canvas_11_1023:0";
            if (jt.get(key) == null) {
                System.out.println("key error: " + key);
                continue;
            }
            flag = true;
            JsonArray a = jt.get(key).getAsJsonArray();
            int l = a.size();
            JsonArray b = a.get(l - 1).getAsJsonArray();
            System.out.print("\t t = " + b.get(0).getAsDouble());
            System.out.println("\t val= " + b.get(1).getAsDouble());

            // 提前指定通道的值
            // canvas_11_1088~canvas_11_1097 代表10个发电机的机端电流
            // canvas_11_1023~canvas_11_1032 代表10个发电机的机端电压
            // 0,1,2代表A，B，C三相
            // System.out.println(jt.get("/canvas_11_1023:0"));//打印发电机31的A相电压
            // 以下代码为读取K33f的值
            // Todo: 读取多个通道的值

            key = "/component_new_channel_439:0"; // K33f
            if (jt.get(key) == null) {
                System.out.println("key error: " + key);
                continue;
            }
            a = jt.get(key).getAsJsonArray();
            l = a.size();
            b = a.get(l - 1).getAsJsonArray();
            System.out.print("\tt = " + b.get(0).getAsDouble());
            System.out.println("\tval= " + b.get(1).getAsDouble());

        }

        // 使用 runner.result.getMessage 获取使用的结果
        // 逐点解析数据
        /*
         * System.out.println("开始解析结果!");
         * JsonParser jParser = new JsonParser();
         * for (int i=20;i<runner.result.getMessage().size()-10;i++ ) {
         * JsonObject jts = (JsonObject)
         * jParser.parse(runner.result.getMessage().get(i));//提取第i个点的数据
         * JsonObject jt = (JsonObject)
         * jParser.parse(jts.get("data").toString());//提取第i个点的数据中的data;
         * System.out.println(jt.get("/canvas_11_1023:0"));//打印发电机31的A相电压
         * //To do , your code here
         * 
         * }
         */

        System.out.println("end");
    }
}
