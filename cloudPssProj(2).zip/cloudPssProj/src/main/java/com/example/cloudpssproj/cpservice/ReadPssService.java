package com.example.cloudpssproj.cpservice;

import com.cloudpss.model.Model;
import com.cloudpss.runner.Runner;
import com.example.cloudpssproj.runner.ReadPssRunner;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import lombok.extern.slf4j.Slf4j;
import net.rubyeye.xmemcached.MemcachedClient;
import net.rubyeye.xmemcached.exception.MemcachedException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.text.DecimalFormat;
import java.util.*;
import java.util.concurrent.TimeoutException;

@Slf4j
@Service
public class ReadPssService {

    @Autowired
    MemcachedClient memcachedClient;

    String taskid;

    public void setFlag(boolean flag) {
        this.stopflag = flag;
    }

    volatile boolean stopflag = true;

    @Async("asyncPssExecutor")
    public void readPss() throws Exception {

        String rid = "model/dpshsw/IEEE39";

        // 加载一个项目
        Model model = Model.fetch(rid);

        // 数据存储通过 result 获取，需要自己监控运行状态，result 为一个迭代器
        Runner runner = model.run();// 启动计算
        //String taskid = runner.getTaskId();
        taskid = runner.getTaskId();

        memcachedClient.set("TASKID", 300, this.taskid);

        int n = 0;

        boolean flag = false;
        //List<Map<String, BigDecimal[]>> canvasValue;
        while (runner.status() == 0) {
            System.out.println("Simulation is running. Waiting ...... " + n);
            Thread.sleep(2000);
            n++;

            if (n > 40 && !flag) {
                log.error("Simulation get message timeout!");
                break;
            }

            if (!runner.result.hasNext())
                continue;

            JsonParser jParser = new JsonParser();
            int lastId = runner.result.getMessage().size() - 1;
            if (lastId < 10)
                continue;

            // 提取第i个点的数据
            String msg = runner.result.getMessage().get(lastId);
            // System.out.println("msg="+msg);
            JsonObject jts = (JsonObject) jParser.parse(msg);
            if (!jts.get("cmd").getAsString().equals("draw"))
                continue;

            // 提取第i个点的数据中的data;
            JsonObject jt = (JsonObject) jParser.parse(jts.get("data").toString());
            if (jt == null)
                continue;
            System.out.println("jt=" + jt);
            setPssMsgMem(jt);
        }
    }

    private void setPssMsgMem(JsonObject jt) throws InterruptedException, TimeoutException, MemcachedException {

        for (String key : ReadPssRunner.map.keySet()) {
            String datakey = ReadPssRunner.map.get(key);
            if (jt.get(datakey) == null) {
                System.out.println("datakey error: " + datakey);
                continue;
            }
            JsonArray a = jt.get(datakey).getAsJsonArray();
            int l = a.size();
            JsonArray b = a.get(l - 1).getAsJsonArray();
            if (key.equals("K2f")) {
                System.out.println("\tt = " + (new DecimalFormat("0.000")).format(b.get(0).getAsDouble()) + " ");
            }
            double v = b.get(1).getAsDouble();
            if (key.contains("K")) {

                if (Math.abs(v - 1.0D) < 1.0E-4D) {
                    memcachedClient.set(key, 300, "1"); continue;
                }
                memcachedClient.set(key, 300, "0");
                continue;
            }
            String val = (new DecimalFormat("0.000")).format(v);
            memcachedClient.set(key, 300, val);
        }
    }

    public Map getPssMsgMem() throws InterruptedException, TimeoutException, MemcachedException {

        //return ReadPssRunner.map.values().stream().collect(Collectors.toList());
        Map map = new HashMap();
        for (String key : ReadPssRunner.map.keySet()) {
            String datakey = ReadPssRunner.map.get(key);
            map.put(key,memcachedClient.get(key));
        }
        return map;
    }

}
