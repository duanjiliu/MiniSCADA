package com.example.cloudpssproj.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.cloudpssproj.entity.Measurement;
import com.example.cloudpssproj.mapper.MeasurementMapper;
import com.example.cloudpssproj.service.IMeasurementService;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author xiaolu
 * @since 2023-09-12
 */
@Service
public class MeasurementServiceImpl extends ServiceImpl<MeasurementMapper, Measurement> implements IMeasurementService {

}
