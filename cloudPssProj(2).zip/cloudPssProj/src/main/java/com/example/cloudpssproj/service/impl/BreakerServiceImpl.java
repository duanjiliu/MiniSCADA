package com.example.cloudpssproj.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.cloudpssproj.entity.Breaker;
import com.example.cloudpssproj.mapper.BreakerMapper;
import com.example.cloudpssproj.service.IBreakerService;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author xiaolu
 * @since 2023-09-12
 */
@Service
public class BreakerServiceImpl extends ServiceImpl<BreakerMapper, Breaker> implements IBreakerService {

}
