package com.example.cloudpssproj.entity;

import io.swagger.annotations.ApiModel;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * <p>
 * 
 * </p>
 *
 * @author xiaolu
 * @since 2023-09-12
 */
@ApiModel(value = "Synchronousmachine对象", description = "")
public class Synchronousmachine implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long id;

    private String name;

    private BigDecimal ratedMW;

    private Long terminal0Id;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public BigDecimal getRatedMW() {
        return ratedMW;
    }

    public void setRatedMW(BigDecimal ratedMW) {
        this.ratedMW = ratedMW;
    }

    public Long getTerminal0Id() {
        return terminal0Id;
    }

    public void setTerminal0Id(Long terminal0Id) {
        this.terminal0Id = terminal0Id;
    }

    @Override
    public String toString() {
        return "Synchronousmachine{" +
            "id = " + id +
            ", name = " + name +
            ", ratedMW = " + ratedMW +
            ", terminal0Id = " + terminal0Id +
        "}";
    }
}
