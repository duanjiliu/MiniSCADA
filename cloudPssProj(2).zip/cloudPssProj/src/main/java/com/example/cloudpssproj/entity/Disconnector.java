package com.example.cloudpssproj.entity;

import io.swagger.annotations.ApiModel;

import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author xiaolu
 * @since 2023-09-12
 */
@ApiModel(value = "Disconnector对象", description = "")
public class Disconnector implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long id;

    private String name;

    private Long terminal0Id;

    private Long terminal1Id;

    private Long normalOpen;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getTerminal0Id() {
        return terminal0Id;
    }

    public void setTerminal0Id(Long terminal0Id) {
        this.terminal0Id = terminal0Id;
    }

    public Long getTerminal1Id() {
        return terminal1Id;
    }

    public void setTerminal1Id(Long terminal1Id) {
        this.terminal1Id = terminal1Id;
    }

    public Long getNormalOpen() {
        return normalOpen;
    }

    public void setNormalOpen(Long normalOpen) {
        this.normalOpen = normalOpen;
    }

    @Override
    public String toString() {
        return "Disconnector{" +
            "id = " + id +
            ", name = " + name +
            ", terminal0Id = " + terminal0Id +
            ", terminal1Id = " + terminal1Id +
            ", normalOpen = " + normalOpen +
        "}";
    }
}
