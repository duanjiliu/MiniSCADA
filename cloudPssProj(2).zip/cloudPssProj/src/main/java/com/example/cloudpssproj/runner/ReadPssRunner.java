package com.example.cloudpssproj.runner;

import com.example.cloudpssproj.constant.PssConstant;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;

@Component
@Order(value = 100)
@Slf4j
public class ReadPssRunner implements ApplicationRunner {

    private Properties config;
    private Properties controlconfig;

    public static ConcurrentHashMap<String, String> map = new ConcurrentHashMap<String,String>();
    public static ConcurrentHashMap<String, String> controlMap = new ConcurrentHashMap<String,String>();

    @Override
    public void run(ApplicationArguments args) throws Exception {
        setSysProp();
        getResourceFileRTU();
    }

    void setSysProp() {
        System.setProperty("CLOUDPSS_API_URL", "http://166.111.60.221:60002/");
        System.setProperty("CLOUDPSS_TOKEN", PssConstant.PSS_TOKEN);
    }

    public void getResourceFileRTU() {
        //InputStream fis = getClass().getClassLoader().getResourceAsStream("resource/RTU.properties");
        InputStreamReader inputStreamReader = new InputStreamReader(getClass().getClassLoader().getResourceAsStream("RTU.properties"), StandardCharsets.UTF_8);

        this.config = new Properties();

        try {
            this.config.load(inputStreamReader);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        Iterator<String> it = this.config.stringPropertyNames().iterator();
        while (it.hasNext()) {
            String key = it.next();
            this.map.put(key, "/" + this.config.getProperty(key) + ":0");
        }

        //fis = getClass().getClassLoader().getResourceAsStream("resource/control.properties");
        InputStreamReader fisReader = new InputStreamReader(getClass().getClassLoader().getResourceAsStream("RTU.properties"), StandardCharsets.UTF_8);

        this.controlconfig = new Properties();
        try {
            this.controlconfig.load(fisReader);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        Iterator<String> it2 = this.controlconfig.stringPropertyNames().iterator();
        while (it2.hasNext()) {
            String key = it2.next();
            this.controlMap.put(key, this.controlconfig.getProperty(key));
        }
    }

}
