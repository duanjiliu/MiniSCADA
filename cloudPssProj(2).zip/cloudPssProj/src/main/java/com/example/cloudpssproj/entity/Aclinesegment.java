package com.example.cloudpssproj.entity;

import io.swagger.annotations.ApiModel;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * <p>
 * 
 * </p>
 *
 * @author xiaolu
 * @since 2023-09-12
 */
@ApiModel(value = "Aclinesegment对象", description = "")
public class Aclinesegment implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long id;

    private String name;

    private BigDecimal r;

    private BigDecimal x;

    private BigDecimal b;

    private Long terminal0Id;

    private Long terminal1Id;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public BigDecimal getR() {
        return r;
    }

    public void setR(BigDecimal r) {
        this.r = r;
    }

    public BigDecimal getX() {
        return x;
    }

    public void setX(BigDecimal x) {
        this.x = x;
    }

    public BigDecimal getB() {
        return b;
    }

    public void setB(BigDecimal b) {
        this.b = b;
    }

    public Long getTerminal0Id() {
        return terminal0Id;
    }

    public void setTerminal0Id(Long terminal0Id) {
        this.terminal0Id = terminal0Id;
    }

    public Long getTerminal1Id() {
        return terminal1Id;
    }

    public void setTerminal1Id(Long terminal1Id) {
        this.terminal1Id = terminal1Id;
    }

    @Override
    public String toString() {
        return "Aclinesegment{" +
            "id = " + id +
            ", name = " + name +
            ", r = " + r +
            ", x = " + x +
            ", b = " + b +
            ", terminal0Id = " + terminal0Id +
            ", terminal1Id = " + terminal1Id +
        "}";
    }
}
