package com.example.cloudpssproj.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.cloudpssproj.entity.Connectivitynode;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author xiaolu
 * @since 2023-09-12
 */
public interface ConnectivitynodeMapper extends BaseMapper<Connectivitynode> {

}
