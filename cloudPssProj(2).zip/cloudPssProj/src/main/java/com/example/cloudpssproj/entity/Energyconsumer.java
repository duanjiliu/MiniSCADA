package com.example.cloudpssproj.entity;

import io.swagger.annotations.ApiModel;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * <p>
 * 
 * </p>
 *
 * @author xiaolu
 * @since 2023-09-12
 */
@ApiModel(value = "Energyconsumer对象", description = "")
public class Energyconsumer implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long id;

    private String name;

    private Long terminal0Id;

    private BigDecimal p;

    private BigDecimal q;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getTerminal0Id() {
        return terminal0Id;
    }

    public void setTerminal0Id(Long terminal0Id) {
        this.terminal0Id = terminal0Id;
    }

    public BigDecimal getP() {
        return p;
    }

    public void setP(BigDecimal p) {
        this.p = p;
    }

    public BigDecimal getQ() {
        return q;
    }

    public void setQ(BigDecimal q) {
        this.q = q;
    }

    @Override
    public String toString() {
        return "Energyconsumer{" +
            "id = " + id +
            ", name = " + name +
            ", terminal0Id = " + terminal0Id +
            ", p = " + p +
            ", q = " + q +
        "}";
    }
}
