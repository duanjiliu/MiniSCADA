package com.example.cloudpssproj.entity;

import io.swagger.annotations.ApiModel;

import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author xiaolu
 * @since 2023-09-12
 */
@ApiModel(value = "Terminal对象", description = "")
public class Terminal implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long id;

    private String name;

    private Long connectivitynode;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getConnectivitynode() {
        return connectivitynode;
    }

    public void setConnectivitynode(Long connectivitynode) {
        this.connectivitynode = connectivitynode;
    }

    @Override
    public String toString() {
        return "Terminal{" +
            "id = " + id +
            ", name = " + name +
            ", connectivitynode = " + connectivitynode +
        "}";
    }
}
