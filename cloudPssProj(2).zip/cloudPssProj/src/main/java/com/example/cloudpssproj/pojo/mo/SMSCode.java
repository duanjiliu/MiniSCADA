package com.example.cloudpssproj.pojo.mo;

import lombok.Data;

@Data
public class SMSCode {
    private String tele;
    private String code;
}
