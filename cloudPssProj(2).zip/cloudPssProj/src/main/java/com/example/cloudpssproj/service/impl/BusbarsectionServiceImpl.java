package com.example.cloudpssproj.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.cloudpssproj.entity.Busbarsection;
import com.example.cloudpssproj.mapper.BusbarsectionMapper;
import com.example.cloudpssproj.service.IBusbarsectionService;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author xiaolu
 * @since 2023-09-12
 */
@Service
public class BusbarsectionServiceImpl extends ServiceImpl<BusbarsectionMapper, Busbarsection> implements IBusbarsectionService {

}
