package com.example.cloudpssproj.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.cloudpssproj.entity.Terminal;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author xiaolu
 * @since 2023-09-12
 */
public interface TerminalMapper extends BaseMapper<Terminal> {

}
