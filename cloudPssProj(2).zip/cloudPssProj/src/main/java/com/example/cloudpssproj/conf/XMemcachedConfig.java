package com.example.cloudpssproj.conf;

import net.rubyeye.xmemcached.MemcachedClient;
import net.rubyeye.xmemcached.MemcachedClientBuilder;
import net.rubyeye.xmemcached.XMemcachedClientBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.IOException;

@Configuration
public class XMemcachedConfig {
    @Bean
    public MemcachedClient getMemcachedClient() throws IOException {
        MemcachedClientBuilder memcachedClientBuilder = new XMemcachedClientBuilder("180.76.142.118:11211");
        memcachedClientBuilder.setConnectionPoolSize(20);
        MemcachedClient memcachedClient = memcachedClientBuilder.build();
        return memcachedClient;
    }


}
