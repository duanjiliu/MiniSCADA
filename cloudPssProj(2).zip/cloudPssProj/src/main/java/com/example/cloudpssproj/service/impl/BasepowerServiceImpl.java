package com.example.cloudpssproj.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.cloudpssproj.entity.Basepower;
import com.example.cloudpssproj.mapper.BasepowerMapper;
import com.example.cloudpssproj.service.IBasepowerService;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author xiaolu
 * @since 2023-09-12
 */
@Service
public class BasepowerServiceImpl extends ServiceImpl<BasepowerMapper, Basepower> implements IBasepowerService {

}
