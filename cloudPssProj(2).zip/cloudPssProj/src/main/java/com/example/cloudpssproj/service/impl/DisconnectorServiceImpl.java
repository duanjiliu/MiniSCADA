package com.example.cloudpssproj.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.cloudpssproj.entity.Disconnector;
import com.example.cloudpssproj.mapper.DisconnectorMapper;
import com.example.cloudpssproj.service.IDisconnectorService;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author xiaolu
 * @since 2023-09-12
 */
@Service
public class DisconnectorServiceImpl extends ServiceImpl<DisconnectorMapper, Disconnector> implements IDisconnectorService {

}
