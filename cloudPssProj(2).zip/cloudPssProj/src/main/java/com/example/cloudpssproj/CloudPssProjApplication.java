package com.example.cloudpssproj;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.example.cloudpssproj.mapper")
public class CloudPssProjApplication {

    public static void main(String[] args) {
        SpringApplication.run(CloudPssProjApplication.class, args);
    }

}
