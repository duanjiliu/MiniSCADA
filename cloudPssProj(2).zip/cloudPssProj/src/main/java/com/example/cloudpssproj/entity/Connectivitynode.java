package com.example.cloudpssproj.entity;

import io.swagger.annotations.ApiModel;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * <p>
 * 
 * </p>
 *
 * @author xiaolu
 * @since 2023-09-12
 */
@ApiModel(value = "Connectivitynode对象", description = "")
public class Connectivitynode implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long id;

    private String name;

    private BigDecimal nominalVoltage;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public BigDecimal getNominalVoltage() {
        return nominalVoltage;
    }

    public void setNominalVoltage(BigDecimal nominalVoltage) {
        this.nominalVoltage = nominalVoltage;
    }

    @Override
    public String toString() {
        return "Connectivitynode{" +
            "id = " + id +
            ", name = " + name +
            ", nominalVoltage = " + nominalVoltage +
        "}";
    }
}
