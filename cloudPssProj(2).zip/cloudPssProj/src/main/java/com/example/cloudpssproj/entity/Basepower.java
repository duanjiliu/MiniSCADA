package com.example.cloudpssproj.entity;

import io.swagger.annotations.ApiModel;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * <p>
 * 
 * </p>
 *
 * @author xiaolu
 * @since 2023-09-12
 */
@ApiModel(value = "Basepower对象", description = "")
public class Basepower implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long id;

    private String name;

    private BigDecimal basePower;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public BigDecimal getBasePower() {
        return basePower;
    }

    public void setBasePower(BigDecimal basePower) {
        this.basePower = basePower;
    }

    @Override
    public String toString() {
        return "Basepower{" +
            "id = " + id +
            ", name = " + name +
            ", basePower = " + basePower +
        "}";
    }
}
