package com.example.cloudpssproj.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author xiaolu
 * @since 2023-09-12
 */
@Controller
@RequestMapping("/aclinesegment")
public class AclinesegmentController {

}
