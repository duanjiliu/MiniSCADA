package com.example.cloudpssproj.cpcontroller;

import com.example.cloudpssproj.cpservice.ReadPssService;
import com.example.cloudpssproj.entity.Basepower;
import com.example.cloudpssproj.runner.ReadPssRunner;
import com.example.cloudpssproj.service.IBasepowerService;
import io.swagger.annotations.ApiOperation;
import net.rubyeye.xmemcached.MemcachedClient;
import net.rubyeye.xmemcached.exception.MemcachedException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.util.List;
import java.util.concurrent.TimeoutException;

@RequestMapping(value = "/demo",method = RequestMethod.GET)
@RestController
public class DemoController {

    @Autowired
    MemcachedClient memcachedClient;

    @Autowired
    IBasepowerService basepowerService;

    @Autowired
    ReadPssService readPssService;

    @GetMapping("/test/set")
    @ApiOperation("测试set")
    public String testMemSet() throws InterruptedException, TimeoutException, MemcachedException {
        memcachedClient.set("tst33", 0, 80);
        return "123";
    }

    @GetMapping("/test/get")
    @ApiOperation("测试get")
    public Object testMemGet() throws InterruptedException, TimeoutException, MemcachedException {
        Object ret = memcachedClient.get("tst33");
        return ret;
    }

    @GetMapping("/test/dbset")
    @ApiOperation("测试set")
    public String testDbSet() throws InterruptedException, TimeoutException, MemcachedException {

        Basepower basepower = new Basepower();
        basepower.setId(new Long(333333));
        basepower.setName("testpower");
        basepower.setBasePower(new BigDecimal(1000));
        basepowerService.save(basepower);
        return "123";
    }

    @GetMapping("/test/dbget")
    @ApiOperation("测试get")
    public Object testMDbGet() throws InterruptedException, TimeoutException, MemcachedException {
        List<Basepower> list = basepowerService.list();
        return list;
    }
}
