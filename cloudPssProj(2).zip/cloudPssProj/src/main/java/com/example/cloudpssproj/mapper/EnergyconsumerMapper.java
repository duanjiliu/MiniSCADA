package com.example.cloudpssproj.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.cloudpssproj.entity.Energyconsumer;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author xiaolu
 * @since 2023-09-12
 */
public interface EnergyconsumerMapper extends BaseMapper<Energyconsumer> {

}
