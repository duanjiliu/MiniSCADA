package com.example.cloudpssproj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudPssProjApplicationTests {

    @Test
    void contextLoads() {
    }

}
